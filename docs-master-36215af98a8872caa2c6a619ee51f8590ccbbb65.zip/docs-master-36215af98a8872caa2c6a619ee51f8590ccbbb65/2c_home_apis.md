## 1. 首页专家列表 Api (需要签名)

    Method: get
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: home/experts
    

#### 响应:

专家：http://apiv2.test.zhizihua.com/consult?#/{id}

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 5,
            "title": "优势心智测评",
            "subtitle": "该测评是知子花教育与清华大学积极心理学研究中心共同研发的专业测评工具。对学生发现自我，家庭教育和教师教学都具有重要意义。",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/em3aghRqwYZInxQm2D0e90sg.jpeg",
            "type": 0
        },
        {
            "id": 8,
            "name": "stress",
            "title": "压力水平测试",
            "subtitle": "压力水平测试",
            "cover": "http://s1.zhizihua.com/interest-test/covers/2017/11-16/7BA8BgRLD3rLjSeacNfvS3Yo.jpeg",
            "type": 1
        },
        {
            "id": 15,
            "title": "自信评估系统",
            "subtitle": "自信是成功的第一秘诀，“天生我材必有用”的豪迈，注定激发你的潜能，发挥你的实力。",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/Z3qxxZn3shaqYSDZTsqmxJxA.jpeg",
            "type": 0
        },
        {
            "id": 10,
            "name": "parentchild",
            "title": "亲子关系：“和谐指数”我知晓",
            "subtitle": "亲子关系：“和谐指数”我知晓",
            "cover": "http://s1.zhizihua.com/interest-test/covers/2017/11-16/1OiNrY8uJ9zZzW4TiElQt5VO.jpeg",
            "type": 1
        },
        {
            "id": 16,
            "title": "教师幸福感测试",
            "subtitle": "幸福是一种心态，幸福是一种能力，幸福是生活的载体。你是否走在幸福的路上？",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/ND2X3pUsIcrVY05rKOVcvNWl.jpeg",
            "type": 0
        }
    ]
}
```

## 2. 首页测评列表 Api (需要签名)

    Method: get
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: home/estimates


#### 响应:

注意：type 字段为 0 为专业测评 1 为趣味测评

趣味测评：http://apiv2.test.zhizihua.com/interest-test/{name}
专业测评：http://apiv2.test.zhizihua.com/estimate/view?#/estimate/{id}

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 5,
            "title": "优势心智测评",
            "subtitle": "该测评是知子花教育与清华大学积极心理学研究中心共同研发的专业测评工具。对学生发现自我，家庭教育和教师教学都具有重要意义。",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/em3aghRqwYZInxQm2D0e90sg.jpeg",
            "type": 0
        },
        {
            "id": 8,
            "name": "stress",
            "title": "压力水平测试",
            "subtitle": "压力水平测试",
            "cover": "http://s1.zhizihua.com/interest-test/covers/2017/11-16/7BA8BgRLD3rLjSeacNfvS3Yo.jpeg",
            "type": 1
        },
        {
            "id": 15,
            "title": "自信评估系统",
            "subtitle": "自信是成功的第一秘诀，“天生我材必有用”的豪迈，注定激发你的潜能，发挥你的实力。",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/Z3qxxZn3shaqYSDZTsqmxJxA.jpeg",
            "type": 0
        },
        {
            "id": 10,
            "name": "parentchild",
            "title": "亲子关系：“和谐指数”我知晓",
            "subtitle": "亲子关系：“和谐指数”我知晓",
            "cover": "http://s1.zhizihua.com/interest-test/covers/2017/11-16/1OiNrY8uJ9zZzW4TiElQt5VO.jpeg",
            "type": 1
        },
        {
            "id": 16,
            "title": "教师幸福感测试",
            "subtitle": "幸福是一种心态，幸福是一种能力，幸福是生活的载体。你是否走在幸福的路上？",
            "cover": "http://s1.zhizihua.com/estimate/home-covers/2017/11-16/ND2X3pUsIcrVY05rKOVcvNWl.jpeg",
            "type": 0
        }
    ]
}
```
# App JS 消息发送说明

## 方法接口

### 一、 JS 发送消息到 app 

接口名称 messageToApp

1. android 附加

附加 zzhApp 对象到 window 然后把 messageToApp 方法附加到 zzhApp 对象
例:

    windows.zzhApp.messageToApp(mesageJson)
    
2. ios 附加

依然使用 webkit messageHandle 方式附加
例:

    window.webkit.messageHandles.messageToApp.postMessage(mesageJson)

### 一、 App 发送消息到 JS

android ios 统一调用 js 方法 window.zzhJs.messageBridge.sendToJs(mesageJson) 并传入消息体

## 消息体说明

消息题统一使用 json 字符串, json 字符串中包含 3 个字段.

1. type: string 表明消息类型。
2. status: int 消息状态,用来表示消息的成功与否与各种状态分支。
3. message: string 消息状态相关的文字说明。
4. data: obj 消息相关的附加数据。

如下:

~~~json
{
    "type": "provideUserToken",
    "status": 200,
    "message": "Token返回完成!",
    "data": {
        "token": "IOBAn67150/SkA0uY0gimoG7fZvh2x5KzTdEmBULLu/ocQ31ybfoAbW1MCggx5AzjA4POEc++opeJkGJUnYADG1lCYqakEKBchId9AbmvybDosYIZVB1vg=="
    }
}
~~~

## 具体消息说明

### 一、token 相关

首先 js 调用消息接口发送消息到 app，然后 app 通过消息接口发送 token 到 js

1. js 发送消息到 app

~~~json
{
    "type": "requestUserToken",
    "status": 200,
    "message": "请求用户token!",
    "data": {}
}
~~~

2. app 发送消息到 js

~~~json
{
    "type": "provideUserToken",
    "status": 200,
    "message": "Token返回完成!",
    "data": {
        "token": "IOBAn67150/SkA0uY0gimoG7fZvh2x5KzTdEmBULLu/ocQ31ybfoAbW1MCggx5AzjA4POEc++opeJkGJUnYADG1lCYqakEKBchId9AbmvybDosYIZVB1vg=="
    }
}
~~~

### 二、分享相关

js 发送消息到 app 并发送 分享相关信息到app, app 吊起分享 ui, 用户分享完成后 app 发送消息到 js 告知 js 用户分享完成。

1. js 调用 app 发送分享信息:

~~~json
{
    "type": "provideShareInfo",
    "status": 200,
    "message": "Token返回完成!",
    "data": {
        "url": "http://someurl.com",
        "img": "http://a.jpg",
        "title": "杰出教子",
        "desc": "杰出教子密码，介绍",
    }
}
~~~

2. app 调用 js 告知 js 用户分享完成。

~~~json
{
    "type": "tellUserShareSuccess",
    "status": 200,
    "message": "分享成功",
    "data": {}
}
~~~

### 三、登陆相关

js 发送消息到 app , 通知 app 调用登陆接口

1. js 调用 app 告知 用户需要登陆

~~~json
{
    "type": "showLogin",
    "status": 200,
    "message": "请求app登陆",
    "data": {}
}
~~~

### 四、音/视频详情相关

js 发送消息到 app , 告知 app 调用 app 的音/视频详情页

1. js 调用 app 的音频详情页

~~~json
{
    "type": "showAudioDetail",
    "status": 200,
    "message": "请求app音频详情页",
    "data": {
        "id":14 // 音频id （int值）
    }
}
~~~

2. js 调用 app 的视频详情页

~~~json
{
    "type": "showVideoDetail",
    "status": 200,
    "message": "请求app视频详情页",
    "data": {
        "id":14 // 视频id （int值）
    }
}
~~~

### 五、支付相关

js 发送消息到 app, 告知 app 调用 app 的支付接口

1. js 调用 app 的支付

~~~json
{
    "type": "showPayment",
    "status": 200,
    "message": "请求APP支付",
    "data": {
        "counselor_info":{
            "create_time": "1513663290000",
            "id": 1,                                   // 专家id
            "interview_price": 0.02,         // 面询价格
            "interview_time": 60,            // 面询时间
            "is_enable": 1, 
            "name": "张雅彬",                 // 专家姓名
            "tel_price": 0.01,                   // 电询价格
            "tel_time": 60,                      // 电询时间
            "update_time": "1513663290000"
        },
        "userinput":{
            "name": "用户姓名"              // 用户姓名
            "tel": "15678894556",         //  电话
            "type": 1,                   //咨询渠道 1 电话 2 面询 （int）
            "amount": 1,                 // 数量
            "total_price": 0.08,               // 总价格
        },
    }
}
~~~

## 响应代码说明

响应异常通过响应 JSON 的 status 字段判断。

### 200 为正常

### 4** 为权限或者用户未登录

1. 401 Jwt 未提供/Jwt 无效/Jwt 指定用户不存在
2. 402 Jwt 超时
3. 404 访问的对象不存在!

### 5** 为服务器异常 或者 请求信息错误

## 签名算法

clientSecret=sADvAoyBUNKSLCMV

nonce=8位随机字符串

timestamp=当前Linux时间戳

signature=(签名字符串: md5(nonce + timestamp + clientSecret))

请求签名的使用类似实例

https://apiv2.test.zhizihua.com/home/subject-videos?nonce=DerdEfdB&timestamp=15712345789&signature=15398c6f84fb5f2b3e3a5a807c6892e0

## jwt 用户认证 

(需要用户登陆)的地方就需要 Jwt 用户认证

通过附加 Http 头 Authorization 发送


# =------------------------------------------ = 认证 = ----------------------------------------------=
### 1. 通过 user_id 换取 Jwt （需要签名）


    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /authorize/get-token

#### 参数:

    | user_id     | int | 用户 id |

#### 响应:
```text
{
    "status": 200,
    "message": "生成完成!",
    "data": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjIyNTAxLCJpc3MiOiJodHRwOi8vYXBpdjIuemhpemkuYXBwL2F1dGhvcml6ZS9nZXQtdG9rZW4iLCJpYXQiOjE1MDg5MTQ1NDEsImV4cCI6MTUxMTUwNjU0MSwibmJmIjoxNTA4OTE0NTQxLCJqdGkiOiJmMXNWUVprNjlqamVKTjZJIn0.dH7CTQP_Hhx6f_XcFPWuhZb_2p5LgFQ-1E43mi0ZRjE"
}
```

## 2. 刷新获取新的 Jwt (需 http 头带原有 jwt)

    Method: get
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /util/refresh-jwt

#### 响应:
```json
{
    "status": 200,
    "message": "刷新完成!",
    "data": {
        "bearer_token": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjIyNTAxLCJpc3MiOiJodHRwOi8vYXBpdjIuemhpemkuYXBwL3V0aWwvcmVmcmVzaC1qd3QiLCJpYXQiOjE1MDg3NDMyODIsImV4cCI6MTUwODc0MzM5MCwibmJmIjoxNTA4NzQzMzMwLCJqdGkiOiJTNlRESUZxeWw5cEhSdzMzIn0.gDUz6V11ZtH6_ockFqATh6hnhzCjhiD8vIwOjTfe34U"
    }
}
```

## 3. 登陆 Api (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /authorize/login-by-password

#### 参数:

    | mobile     | int | 学历 |
    | password   | int | 分页 |

#### 响应:
```json
{
    "status": 200,
    "message": "用户登录成功",
    "data": {
        "user": {
            "id": 22544,
            "username": "13261056658",
            "mobile": "13261056658",
            "gender": 1,
            "age": 8,
            "name": "132****6658",
            "nickname": "",
            "avatar": "",
            "childname": "孩子",
            "level": 6,
            "birthday": "1230739200",
            "login_time": 1508912805,
            "last_time": 1508912805,
            "create_time": 1504786834,
            "key": "f9e2d1af5d3b579f69d6dbc33b373e70",
            "sore": 0,
            "money": "0.00",
            "status": 0,
            "qq": "",
            "wechat_service_id": "",
            "wechat_subscribe_id": "",
            "wechat_uuid": null,
            "regsource": 0,
            "regchannel": "",
            "client_version": "",
            "jump": 2,
            "token_id": "",
            "is_test": 0,
            "logined_at": {
                "date": "2017-10-25 14:26:44.890282",
                "timezone_type": 3,
                "timezone": "Asia/Shanghai"
            },
            "created_at": null,
            "originavatar": ""
        },
        "bearer_token": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjIyNTQ0LCJpc3MiOiJodHRwOi8vYXBpdjIuemhpemkuYXBwL2F1dGhvcml6ZS9sb2dpbi1ieS1wYXNzd29yZCIsImlhdCI6MTUwODkxMjgwNSwiZXhwIjoxNTExNTA0ODA1LCJuYmYiOjE1MDg5MTI4MDUsImp0aSI6IjNmVnhPTU1ESEJrQzJPQXMifQ.p6ncGYUw0r44AXLoUwrr1i4qenwot1gMSCvBlqyATHA"
    }
}
```

# =------------------------------------------ = 首页接口 = ------------------------------------------=

## 1. 首页视频栏目列表 Api (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /home/subject-videos

#### 参数:

    | education | int    | 学历         |
    | page      | int    | 分页         |
    | uuid      | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 2,
            "name": "一年级第二期",
            "price": 0,
            "description": "一年级第二期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "video_count": 1,
            "subscribe_count": 1,
            "user_subcribe": 1
        },
        {
            "id": 1,
            "name": "一年级第一期",
            "price": 0,
            "description": "一年级第一期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "video_count": 4,
            "subscribe_count": 4,
            "user_subcribe": 1
        }
    ]
}
```

## 2. 首页音频栏目列表 Api (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /home/subject-audios
    
#### 参数:

    | uuid      | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 1,
            "name": "音频 第一期",
            "price": 0,
            "description": "音频 第一期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "audio_count": 3,
            "subscribe_count": 3,
            "user_subcribe": 1
        }
    ]
}
```

## 2. 轮播(需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /home/rolling.
    
#### 跳转规则:    

    1. app://{module}/{id}
    module 表示跳转到模块 estimate 测聘 consult 名师 video 视频 audio 音频
    id 子条目 id
    
    示例：
    app://video 表示跳转到 视频栏目列表
    app://video/1 表示跳转到栏目 1
    
    
    2. http://fdfs.com
    html5 链接
    
    
#### 响应:
```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 19,
            "title": "视频: 如何培养一个自信乐观的孩子",
            "image": "2017/10-29/4b7pGMbsVpk79sDL0yRgPFFR.jpeg",
            "jump": "app://video/17",
            "order": 1,
            "is_hide": 0,
            "created_at": "2016-11-16 11:19:57",
            "updated_at": "1970-01-01 08:33:37"
        },
        {
            "id": 16,
            "title": "曹廷珲 : 杰出教子密码",
            "image": "2017/10-29/rQOPnS1RfMIRBU5gH1ZKMHT1.jpeg",
            "jump": "app://audio/4",
            "order": 2,
            "is_hide": 0,
            "created_at": "2016-06-01 12:00:53",
            "updated_at": "1970-01-01 08:33:37"
        },
        {
            "id": 15,
            "title": "专家列表",
            "image": "2017/10-29/dEXvltAPyhdqi03mnY4Aw1rP.jpeg",
            "jump": "app://estimate/1",
            "order": 3,
            "is_hide": 0,
            "created_at": "2016-11-07 10:40:21",
            "updated_at": "1970-01-01 08:33:37"
        },
        {
            "id": 20,
            "title": "自信测评",
            "image": "2017/10-29/odVAQpI4UJ835htauZJ5pXjm.jpeg",
            "jump": "app://estimate/15",
            "order": 4,
            "is_hide": 0,
            "created_at": "2016-11-07 10:38:38",
            "updated_at": "1970-01-01 08:33:37"
        },
        {
            "id": 18,
            "title": "专家1",
            "image": "2017/10-29/ktQDAZYa4LAAOgmniSlXGy0b.jpeg",
            "jump": "app://consult/1",
            "order": 5,
            "is_hide": 0,
            "created_at": "2016-07-15 18:31:04",
            "updated_at": "1970-01-01 08:33:37"
        }
    ]
}
```

# =------------------------------------------ = 视频接口 = ------------------------------------------=

## 1. 视频栏目列表接口 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/videos


#### 参数:

    | education | int|string | int 学历  sting 'free' 免费    |
    | page      | int        | 分页     |
    | uuid      | string     | 苹果uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 26,
            "name": "言教不如身教",
            "price": 0,
            "description": "孩子的一言一行，一举一动，都受家长潜移默化的影响，身教更是大于言传，所以想要让自己的孩子优秀，就要家长提升自我修养，做孩子的好榜样！",
            "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/11-03/0kdsbFp7XNufIOcTpJ2OJ3sM.jpeg",
            "icon": "http://s1.zhizihua.com/videos/topic-icons/2017/11-03/3fZ92ZZDfhkXQajNRe3YOqOU.jpeg",
            "video_count": 1,
            "subscribe_count": 0,
            "user_subcribe": 0,
            "play_count": 6
        }
    ]
}
```

## 4. 视频栏目详情接口 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/videos/{id}

#### 参数:

    | id   | int    | 专栏 ID   |
    | uuid | string | 苹果 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "id": 23,
        "name": "打开压力的调节器",
        "price": 29,
        "description": "教孩子调节压力，不做情绪的奴隶",
        "detail": [
            "http://s1.zhizihua.com/videos/topic-detail/2017/11-01/CFcPxNgySeAbXrXeKe8AU22v.jpeg",
            "http://s1.zhizihua.com/videos/topic-detail/2017/11-01/3L3djrCLshdJswq5twyqIpR5.jpeg",
            "http://s1.zhizihua.com/videos/topic-detail/2017/11-01/XjFomTHqy2emQ2ytl2AmZowt.jpeg",
            "http://s1.zhizihua.com/videos/topic-detail/2017/11-01/6D2IizBV9RoBECsbzbPutBJd.jpeg",
            "http://s1.zhizihua.com/videos/topic-detail/2017/11-01/XVkWhe9qnSVU2OE7XIh7LL3a.jpeg"
        ],
        "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/11-01/XKeVc5APaRKasVFI7z0D5PeC.jpeg",
        "icon": "http://s1.zhizihua.com/videos/topic-icons/2017/11-02/oGKUYio5nNqlqnem7Pth41hu.jpeg",
        "video_count": 4,
        "subscribe_count": 7,
        "user_subcribe": 0,
        "play_count": 109
    }
}
```

## 5. 视频列表接口 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/videos/{id}/list


#### 参数:

    | id     | int    | 专栏 id   |
    | page   | int    | 分页页数  |
    | uuid   | string | 苹果 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "user_subcribe": true,
        "videos": [
            {
                "id": 1,
                "title": "第一课第一小节",
                "video_link": "http://vodiwy0jh9q.vod.126.net/vodiwy0jh9q/300deZl3_23945862_shd.mp4",
                "uploaded_at": "2017-10-17 13:27:13",
                "play_count": 5
            },
            {
                "id": 2,
                "title": "第一课第二小节",
                "video_link": "http://vodiwy0jh9q.vod.126.net/vodiwy0jh9q/YsHoNdy2_23945811_shd.mp4",
                "uploaded_at": "2017-10-17 13:27:13",
                "play_count": 0
            },
            {
                "id": 3,
                "title": "第一课第三小节",
                "video_link": "http://vodiwy0jh9q.vod.126.net/vodiwy0jh9q/nF1ndfFo_23947640_shd.mp4",
                "uploaded_at": "2017-10-17 13:27:13",
                "play_count": 0
            },
            {
                "id": 4,
                "title": "第一课第四小节",
                "video_link": "http://vodiwy0jh9q.vod.126.net/vodiwy0jh9q/W2SVY0Hc_23946423_shd.mp4",
                "uploaded_at": "2017-10-17 13:27:13",
                "play_count": 0
            }
        ]
    }
}
```



## 6. 记录视频播放 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/videos/play-video


#### 参数:

    | id   | int    | 视频 id   |
    | uuid | string | 苹果 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
}
```


# =------------------------------------------ = 音频接口 = ------------------------------------------=

## 1. 音频栏目列表接口 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/audios

#### 参数:

    | page | int    | 分页         |
    | uuid | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 1,
            "name": "音频 第一期",
            "price": 0,
            "description": "音频 第一期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "audio_count": 3,
            "subscribe_count": 1,
            "user_subcribe": 1
        }
    ]
}
```

## 4. 音频栏目详情 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/audios/{id}

#### 参数:

    | id   | int    | 音频专栏 id  |
    | uuid | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "id": 1,
        "name": "音频 第一期",
        "price": 0,
        "description": "音频 第一期 简介",
        "detail": "音频 第一期 详情",
        "cover": "2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
        "audio_count": 3,
        "subscribe_count": 1,
        "user_subcribe": 1
    }
}
```

## 5. 音频列表 (需要签名)

    Method: get
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/audios/{id}/list

#### 参数:

    | id   | int    | 音频专栏 id   |
    | uuid | string | 苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "user_subcribe": true,
        "audios": [
            {
                "id": 1,
                "title": "第一期 音频一",
                "audio_link": "http://fdfs.xmcdn.com/group23/M00/04/1F/wKgJL1gRmvbQrA2MABoW9DCHRoU159.mp3",
                "uploaded_at": "2017-10-18 10:51:12",
                "play_count": 3
            },
            {
                "id": 2,
                "title": "第一期 音频二",
                "audio_link": "http://fdfs.xmcdn.com/group24/M08/07/E9/wKgJMFgS85CjUJ8PAB0LsKrL4xg014.mp3",
                "uploaded_at": "2017-10-18 10:51:12",
                "play_count": 1
            },
            {
                "id": 3,
                "title": "第一期 音频三",
                "audio_link": "http://fdfs.xmcdn.com/group23/M04/00/FF/wKgJNFgQXJ3RxGcKAB8MV2Onnz4087.mp3",
                "uploaded_at": "2017-10-18 10:51:12",
                "play_count": 0
            }
        ]
    }
}
```

## 6. 记录音频播放 (需要签名) (需要用户登陆)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/audios/play-audio


#### 参数:

    | id   | int    | 音频 id   |
    | uuid | string | 苹果 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
}
```

# =------------------------------------------ = 订阅接口 = ------------------------------------------=

## 1. 订阅视频栏目列表 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/videos/mine
    
#### 参数:

    | uuid | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 1,
            "name": "一年级第一期",
            "price": 0,
            "description": "一年级第一期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "video_count": 4,
            "subscribe_count": 4
        }
    ]
}
```


## 2. 订阅音频栏目列表 (需要签名) (需要用户登陆)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /subject/audios/mine
    
#### 参数:

    | uuid | string |苹果设备 uuid |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "id": 1,
            "name": "一年级第一期",
            "price": 0,
            "description": "一年级第一期 简介",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "video_count": 4,
            "subscribe_count": 4
        }
    ]
}
```

# =------------------------------------------ = 咨询接口 = ------------------------------------------=

## 1. 咨询页面

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /consult
    
## 注意

    android 附件对象 appCaller

    Webkit 初始化时需要提供 3 个 js 接口
    
    appGetJwt      // 调用时返回 App Jwt. 如用户未登录 返回空 字符串.
    appCallPayment // 调用时通知 App 调起支付, js 会向 App 传递一个参数为 orderId.
    appCallLogin   // 调用时调起 App 登陆界面.

#### 响应:

```json
html
```

# =------------------------------------------ = 测评接口 = ------------------------------------------=

## 1. 咨询页面

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /estimate/view
    
## 注意

    android 附件对象 appCaller
    
    Webkit 初始化时需要提供 3 个 js 接口
    
    appGetJwt      // 调用时返回 App Jwt. 如用户未登录 返回空 字符串.
    appCallPayment // 调用时通知 App 调起支付, js 会向 App 传递一个参数为 orderId.
    appCallLogin   // 调用时调起 App 登陆界面.

#### 响应:

```json
html
```

# =------------------------------------------ = 支付 = ------------------------------------------=

## 1. 生成订单号 创建订单 (需要登录)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/generate-order

#### 参数:

    | product_type | int | 产品类型 id |
    | product_id | int | 产品 id |
    
#### ProductType 

    const PRODUCT_BALANCE  = 1;         // 充值余额
    const PRODUCT_ESTIMATE = 2;         // 测评
    const PRODUCT_SUBJECT  = 3;         // 专栏
    const PRODUCT_CONSULT_SERVICE = 4;  // 咨询
    const PRODUCT_TEST = 5;             // 老版测评
    const PRODUCT_SUBJECT_VIDEO = 6;    // 订阅视频
    const PRODUCT_SUBJECT_AUDIO = 7;    // 订阅音频

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "product_info": {
            "available": true,
            "title": "张雅彬",
            "price": 0.01
        },
        "order_info": {
            "id": "11248095453775132909",
            "user_id": 12409,
            "product_type": 4,
            "product_id": 1,
            "log_id": 4,
            "status": 2,
            "coupon_id": 0,
            "amount": "0.01",
            "attach": {
                "name": "李佳",
                "mobile": "15369302578",
                "package": "1"
            },
            "paid_user": "",
            "trade": "4200000023201710209254801162",
            "paid_channel": 2,
            "created_at": "2017-10-20 19:11:57",
            "confirmed_at": null,
            "paid_at": "2017-10-20 19:12:03",
            "canceled_at": null,
            "used_at": null,
            "is_delete": 0
        },
        "user_balance": "4999.88"
    }
}
```

## 2. 订单详情接口 (需要登录)

    Method: get
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/order-detail/{id}

#### 参数:

    | id | int | 订单 id |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": {
        "product_info": {
            "available": true,
            "title": "张雅彬",
            "price": 0.01
        },
        "order_info": {
            "id": "11248095453775132909",
            "user_id": 12409,
            "product_type": 4,
            "product_id": 1,
            "log_id": 4,
            "status": 2,
            "coupon_id": 0,
            "amount": "0.01",
            "attach": {
                "name": "李佳",
                "mobile": "15369302578",
                "package": "1"
            },
            "paid_user": "",
            "trade": "4200000023201710209254801162",
            "paid_channel": 2,
            "created_at": "2017-10-20 19:11:57",
            "confirmed_at": null,
            "paid_at": "2017-10-20 19:12:03",
            "canceled_at": null,
            "used_at": null,
            "is_delete": 0
        },
        "user_balance": "4999.88"
    }
}
```


## 3. 校验优惠码/使用优惠码支付 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/valid-coupon

#### 参数:

    | order_id      | int    | 订单 id |
    | coupon_secret | string | 优惠码  |

#### 响应:


```json
{
    "status": 200,
    "message": "服务添加成功!",
    "data": {
        "price": 0.01,
        "payment_price": 0
    }
}
```
## 4. IOS 未登录创建订单 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/iap-create-order

#### 参数:

    | uuid          | string | Ios 唯一ID    |
    | product_type  | int    | 产品类型 ID   |
    | product_id    | int    | 产品 ID       |

#### 响应:

```json
{
    "status": 200,
    "message": "订单号生成完成",
    data: {
        "product_info": {
            "available": true,
            "title": "视频第一期",
            "price": 0.01
        },
        "order_info": {
            "id": "11248095453775132909",
            "user_id": 12409,
            "product_type": 4,
            "product_id": 1,
            "log_id": 4,
            "status": 2,
            "coupon_id": 0,
            "amount": "0.01",
            "attach": [],
            "paid_user": "",
            "trade": "4200000023201710209254801162",
            "paid_channel": 2,
            "created_at": "2017-10-20 19:11:57",
            "confirmed_at": null,
            "paid_at": "2017-10-20 19:12:03",
            "canceled_at": null,
            "used_at": null,
            "is_delete": 0
        }
    }
}
```


## 4. 苹果订阅 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/apple-purchase

#### 参数:

    | order_id       | int    | 订单 ID       |
    | receipt        | string | 苹果订单凭据  |
    | transaction_id | string | 苹果订单号    |

#### 响应:

```json
{
    "status": 200,
    "message": "服务添加成功"
}
```

## 5. 支付宝参数签名 (需要签名)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/alipay-query-sign
    

#### 参数:

    | query     | string   | 支付参数      |

#### 响应:

```json
{
    "status": 200,
    "message": "签名完成",
    "data": {
        "signed_query": "&sign=\"V4hwBDO0GfwBflqaj2yT4HHjf2xDWW0TdfiizPPrkuUu25EIhbU%2BlyQcnHZYQAzLutntIGrwDvkcTSJGN%2BugjnG2gCj8NRbAAAZDsKnxhom2LqT05tx3ThJP1nV7HXv9bUjmZZ78Zzyevx4fmQKPUjPgu0rznfpEGvoXktygeoY%3D\"&sign_type=\"RSA\""
    }
}
```


## 6. 支付宝回调参数
    
    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /payment/callback-alipay


    | out_trade_no | int   | OrderId                                            |
    | attach       | jason |   coupon_secret 优惠码 debug: a-4.2.4-w-15234343343 |
    
## 7. 微信回调参数

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /app/payment/callback-wechat

    | out_trade_no | int   | OrderId                                             |
    | attach       | jason |   coupon_secret 优惠码 debug: a-4.2.4-w-15234343343 |
    
### Debug 代码
    第一段：平台 i ios, a android
    第二段：客户端版本号
    第三段：支付渠道: a lipay, w wechat
    第四段：时间戳 秒级
    

# =------------------------------------------ = 我的接口 = ------------------------------------------=
## 1. 我的订单 (需要登陆)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /mine/order
    
#### 参数:

    | page   | int   | 支付参数   |

#### 响应:

```json
{
    "status": 200,
    "message": "读取完成!",
    "data": [
        {
            "id": "11251430938405134042",
            "amount": "0.00",
            "product_type": 6,
            "product_id": 2,
            "created_at": "2017-10-25 21:20:41",
            "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/10-17/bc7b36fe4d2924e49800d9b3dc4a325c.png",
            "price": 0.01,
            "title": "一年级第二期"
        },
        {
            "id": "11251430938405132638",
            "amount": "0.00",
            "product_type": 6,
            "product_id": 2,
            "created_at": "2017-10-25 21:17:42",
            "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/10-17/bc7b36fe4d2924e49800d9b3dc4a325c.png",
            "price": 0.01,
            "title": "一年级第二期"
        },
        {
            "id": "11252424332065132931",
            "amount": "0.00",
            "product_type": 6,
            "product_id": 1,
            "created_at": "2017-10-25 19:27:18",
            "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/10-17/bc7b36fe4d2924e49800d9b3dc4a325c.png",
            "price": 0.01,
            "title": "一年级第一期"
        },
        {
            "id": "11252367977885132990",
            "amount": "0.00",
            "product_type": 6,
            "product_id": 1,
            "created_at": "2017-10-25 17:52:51",
            "cover": "http://s1.zhizihua.com/videos/topic-covers/2017/10-17/bc7b36fe4d2924e49800d9b3dc4a325c.png",
            "price": 0.01,
            "title": "一年级第一期"
        },
        {
            "id": "11252338147765123123",
            "amount": "0.00",
            "product_type": 2,
            "product_id": 5,
            "created_at": "2017-10-25 17:03:07",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/08-21/PyooOmoQlgCUDR2wCkGKpGy7.jpeg",
            "price": 15.8,
            "title": "优势心智测评"
        },
        {
            "id": "11252328724325122484",
            "amount": "0.00",
            "product_type": 2,
            "product_id": 15,
            "created_at": "2017-10-25 16:47:24",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/10-11/rCVNoJh5xEE4K2QKwUBzVcJB.jpeg",
            "price": 11.8,
            "title": "自信评估系统"
        }
    ]
}
```

## 2. 我的测评-未测评 (需要登陆)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /mine/estimate/un-complete
    
#### 参数:

    | page   | int   | 支付参数   |
    
#### 跳转说明

    1. 测评 详情
    /estimate?#/estimate/{id}
    2. 测评 报告
    /estimate?#/estimate/{测评id estimate_id}/report?log={log_id}


#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "estimate_id": 5,
            "log_id": 12,
            "title": "优势心智测评",
            "suit": "中小学生",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/08-21/PyooOmoQlgCUDR2wCkGKpGy7.jpeg",
            "price": 15.8,
            "is_used": 0,
            "order_id": "11247253979055132625"
        }
    ]
}
```

## 3. 我的测评-已测评 (需要登陆)

    Method: post
    BaseUrl: http://apiv2.test.zhizihua.com
    Url: /mine/estimate/complete
    
#### 参数:

    | page   | int   | 支付参数   |

#### 响应:

```json
{
    "status": 200,
    "message": "",
    "data": [
        {
            "estimate_id": 5,
            "log_id": 7,
            "title": "优势心智测评",
            "cover": "http://s1.zhizihua.com/estimate/covers/2017/08-21/PyooOmoQlgCUDR2wCkGKpGy7.jpeg",
            "price": 15.8,
            "is_used": 1,
            "order_id": "11246049149165132364"
        }
    ]
}
```

## 4. 我的咨询

## 1. 微信 Code 提交获取登陆信息接口。